# Importation des modules externes
import random
import os
import numpy as np

# Définition de la classe Puissance4
class Puissance4:

    def __init__(self):
        '''Initialise la classe Puissance4 avec un plateau vide de 6 lignes et 7 colonnes.'''
        # La matrice 2D (plateau) est représentée par un tableau NumPy de dimensions 6x7, initialisé à zéro.
        self.plateau = np.zeros((6, 7))

    def afficher(self):
        '''Affiche de manière graphique le plateau de jeu dans la console.'''
        for i in range(5, -1, -1):  # Parcours du plateau de bas en haut
            for j in range(len(self.plateau[i])):
                val = int(self.plateau[i][j])
                if val == 0:
                    val = ' '
                elif val == 1:
                    val = 'X'
                elif val == 2:
                    val = 'O'
                print('|', val, sep='', end='')
            print('|')
        print('-' * 15)
        for i in range(len(self.plateau[0])):
            print('', i + 1, end='')  # Affiche les numéros de colonne
        print()

    def combiendanscolonne(self, numcolonne):
        '''Retourne le nombre de pions déjà présents dans la colonne demandée (numcolonne).'''
        k = 0
        for i in range(5):
            if (self.plateau[i][numcolonne] == 1) or (self.plateau[i][numcolonne] == 2):
                k += 1
        return k

    def empiler(self, couleur, numcolonne):
        '''Empile les pions dans le plateau en fonction de la colonne et de la couleur.'''
        for i in range(len(self.plateau)):
            if int(self.plateau[i][numcolonne]) == 0:
                self.plateau[i][numcolonne] = couleur
                return (i, numcolonne)

    def colonne_pleine(self, numcolonne):
        '''Détermine si la colonne considérée est pleine ou non.'''
        i = len(self.plateau) - 1
        if self.plateau[i][numcolonne] > 0:
            return True
        else:
            return False

    def hors_limites(self, numcolonne):
        '''Détermine si nous sommes hors des limites du plateau ou non.'''
        if (numcolonne < 0) or (numcolonne >= len(self.plateau[0])):
            return True
        else:
            return False

    def combien_dans_la_direction(self, l, c, dv, dc):
        '''Retourne le nombre de pions consécutifs de la même couleur que le pion situé à la ligne l et à la colonne c.'''
        nbC = len(self.plateau[0])
        nbL = len(self.plateau)
        jeton = self.plateau[l][c]
        nbre = 0
        while (l + dv >= 0 and l + dv < nbL and c + dc >= 0 and c + dc < nbC and self.plateau[l + dv][c + dc] == jeton):
            nbre += 1
            l += dv
            c += dc
        return nbre

    def test_lignes(self, i, j):
        '''Détermine si 4 pions sont alignés sur une ligne.'''
        l = self.combien_dans_la_direction(i, j, 0, 1)
        l += self.combien_dans_la_direction(i, j, 0, -1)
        return l >= 3

    def test_colonnes(self, i, j):
        '''Détermine si 4 pions sont alignés sur une colonne.'''
        c = self.combien_dans_la_direction(i, j, 1, 0)
        c += self.combien_dans_la_direction(i, j, -1, 0)
        return c >= 3

    def test_diagonale(self, i, j):
        '''Détermine si 4 pions sont alignés sur une diagonale.'''
        d1 = self.combien_dans_la_direction(i, j, 1, 1)
        d1 += self.combien_dans_la_direction(i, j, -1, -1)
        d2 = self.combien_dans_la_direction(i, j, 1, -1)
        d2 += self.combien_dans_la_direction(i, j, -1, 1)
        return (d1 >= 3) or (d2 >= 3)

    def test_tout(self, i, j):
        '''Détermine si 4 pions sont alignés sur une ligne, une colonne, ou une diagonale.'''
        l = self.test_lignes(i, j)













