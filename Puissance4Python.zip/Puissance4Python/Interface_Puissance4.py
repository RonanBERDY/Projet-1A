# Importation du module Tkinter pour l'interface graphique
from tkinter import Tk, Button, Canvas, TOP
from Puissance4 import *

# Définition de la classe Application
class Application:

    def __init__(self, nblignes, nbcolonnes):
        '''Constructeur de la fenêtre principale.'''
        # Initialisation des attributs de la classe
        self.nblignes = nblignes
        self.nbcolonnes = nbcolonnes
        self.jeu = Puissance4()  # Instance de la classe Puissance4
        self.joueur = 1
        self.fenn = Tk()  # Création de la fenêtre Tkinter
        self.fenn.title('Le jeu de puissance 4')  # Titre de la fenêtre
        Button(self.fenn, text="Nouveau Jeu", command=self.nouveau_jeu).pack()  # Bouton Nouveau Jeu
        Button(self.fenn, text="Quitter", command=self.fenn.destroy).pack()  # Bouton Quitter
        self.can = Canvas(self.fenn, width=400, height=430, bg='blue')  # Zone de dessin (Canvas)
        self.can.pack(side=TOP, padx=5, pady=5)  # Placement du Canvas dans la fenêtre
        self.can.create_rectangle(10, 425, 100, 400, fill="light blue", activefill="pink", outline="black", width=1)
        self.mylabel = self.can.create_text((40, 410), text="Joueur")  # Texte affichant le joueur actuel
        self.color = ["yellow", "red"]  # Couleurs des jetons des joueurs
        self.x = 75
        self.y = 412
        self.r = 10
        # Création du jeton du joueur actuel sur le côté de la fenêtre
        self.can.create_oval(self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r,
                              fill=self.color[self.joueur], outline="black")
        self.fenn.mainloop()  # Lancement de la boucle principale de la fenêtre

    def dessiner_plateau(self):
        '''Dessine le plateau de jeu dans le Canvas.'''
        for i in range(self.nblignes):
            for j in range(self.nbcolonnes):
                x1 = 50 + 50 * j - 25
                x2 = 50 + 50 * j + 25
                y1 = 50 + 50 * i - 25
                y2 = 50 + 50 * i + 25
                self.can.create_oval(x1, y1, x2, y2, fill='white')

    def nouveau_jeu(self):
        '''Initialise un nouveau jeu en dessinant le plateau et en liant la fonction clic à l'événement souris.'''
        self.dessiner_plateau()
        self.can.bind('<Button-1>', self.clic)

    def clic(self, event):
        '''Fonction pour la détection des évènements souris.'''
        x = event.x - 25
        y = event.y

        self.jeu.afficher()  # Affiche l'état actuel du jeu dans la console

        i, j = self.jeu.empiler(self.joueur, x // 50)

        c = x // 50
        x1 = c * 50 + 25
        x2 = x1 + 50
        y1 = (5 - i) * 50 + 25
        y2 = y1 + 50

        # Création du jeton dans le Canvas à l'emplacement du clic
        self.can.create_oval(x1, y1, x2, y2, fill=self.color[self.joueur - 1])
        # Création du jeton du joueur actuel sur le côté de la fenêtre
        self.can.create_oval(self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r,
                              fill=self.color[self.joueur - 1], outline="black")

        if self.jeu.test_tout(i, j):
            # Affiche le message indiquant quel joueur a gagné
            self.mylabel = self.can.create_text((200, 410), text="Joueur " + str(self.joueur - 1) + " a gagné",
                                                fill='white')

        # Change de joueur pour le prochain tour
        if self.joueur == 1:
            self.joueur = 2
        else:
            self.joueur = 1

# Crée une instance de la classe Application avec un plateau de 6 lignes et 7 colonnes
app = Application(6, 7)


